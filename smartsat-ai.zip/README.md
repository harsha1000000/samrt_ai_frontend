# SmartSAT AI — Test User Discovery Assistant (POC)

An AI-powered assistant that recommends the right SAT (test) user for a given
Peregrine module (RSM, CMAX, Retirement Readiness, Paycheck Deduction,
Contributions), combining a RAG-style pipeline with semantic search over
SAT user profiles — instead of manually digging through Excel and SME
knowledge.

This repo is a runnable proof-of-concept built from the hackathon idea
submission, with **dummy data** standing in for real SAT/client records.

```
smartsat-ai/
├── backend/     Spring Boot (Java 17) REST API + RAG/semantic search engine
└── frontend/    React (Vite) UI
```

## How the "RAG + Semantic Search" works here

1. **Retrieve** — `SemanticSearchService` filters the dummy SAT user dataset
   down to the selected module (the "module-specific business rules" step),
   then ranks the remaining candidates by similarity between your typed
   scenario and each user's profile.
2. **Rank** — similarity is computed by `EmbeddingService`, which builds a
   TF-IDF vector space over all SAT user profiles at startup and scores
   candidates with cosine similarity. This is a dependency-free, zero-API-key
   stand-in for a real embedding model, built so the whole POC runs offline.
3. **Generate** — `SemanticSearchService.buildExplanation(...)` produces the
   "why this user" text. It's template-based here; in production this is
   exactly where you'd hand the retrieved profiles + your scenario to an LLM
   (Azure OpenAI / OpenAI GPT) to generate the explanation.

### Swapping in real embeddings / GPT later

- `application.properties` already has placeholders for
  `smartsat.embeddings.provider`, Azure OpenAI endpoint/key/deployment, and
  OpenAI key/model.
- `EmbeddingService` has a marked extension point (`embedRemote(...)`) —
  implement the HTTP call to `/embeddings` there and swap the local
  TF-IDF vectorizer for it. `SemanticSearchService` doesn't need to change.
- Swap `buildExplanation(...)` for a real Chat Completions call once you want
  LLM-generated (rather than templated) reasoning — the retrieved SAT user
  profiles are already exactly the context you'd pass in.

## Running the backend

Requires Java 17+ and Maven.

```bash
cd backend
mvn spring-boot:run
```

The API starts on `http://localhost:8080`. Key endpoints:

| Method | Path             | Description                                   |
|--------|------------------|------------------------------------------------|
| GET    | `/api/modules`   | List of Peregrine modules in the dataset       |
| GET    | `/api/users?module=RSM` | Raw SAT users (optionally filtered)     |
| POST   | `/api/recommend` | `{ module, scenario, topK }` → ranked matches  |
| GET    | `/api/kpis`      | Demo KPI targets shown on the dashboard        |
| GET    | `/api/use-case`  | Idea summary / value chain / personas          |

## Running the frontend

Requires Node.js 18+.

```bash
cd frontend
npm install
npm run dev
```

Opens on `http://localhost:5173` and proxies `/api/*` to the backend on
`:8080` (see `vite.config.js`).

## Dummy data

`backend/src/main/resources/data/sat_users.json` contains 21 fabricated SAT
users spread across the five modules from the idea submission, each with a
client name, plan type, roles, and a descriptive test scenario — enough
variety for the semantic search to produce meaningfully different rankings
per query. Replace this file (or swap `DummyDataLoader` for a real
repository/DB call) to point at real data.

## Notes on the demo KPIs

The four KPI targets shown on the dashboard (discovery time, productivity,
SME dependency, release cycle time) are the targets captured in the original
idea submission, surfaced here as static display data — not computed from
live telemetry. Wire `/api/kpis` up to real usage analytics once this moves
past POC.
