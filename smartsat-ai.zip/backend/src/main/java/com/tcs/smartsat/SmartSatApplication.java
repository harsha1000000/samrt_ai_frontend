package com.tcs.smartsat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartSatApplication {
    public static void main(String[] args) {
        SpringApplication.run(SmartSatApplication.class, args);
    }
}
