package com.tcs.smartsat.controller;

import com.tcs.smartsat.data.DummyDataLoader;
import com.tcs.smartsat.model.RecommendationRequest;
import com.tcs.smartsat.model.RecommendationResult;
import com.tcs.smartsat.model.SatUser;
import com.tcs.smartsat.service.EmbeddingService;
import com.tcs.smartsat.service.SemanticSearchService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class SatUserController {

    private final DummyDataLoader dataLoader;
    private final SemanticSearchService searchService;
    private final EmbeddingService embeddingService;

    public SatUserController(DummyDataLoader dataLoader, SemanticSearchService searchService,
                              EmbeddingService embeddingService) {
        this.dataLoader = dataLoader;
        this.searchService = searchService;
        this.embeddingService = embeddingService;
    }

    @GetMapping("/modules")
    public List<String> getModules() {
        return dataLoader.getAllModules();
    }

    @GetMapping("/users")
    public List<SatUser> getAllUsers(@RequestParam(required = false) String module) {
        return module == null ? dataLoader.getAllUsers() : dataLoader.getByModule(module);
    }

    @PostMapping("/recommend")
    public List<RecommendationResult> recommend(@Valid @RequestBody RecommendationRequest request) {
        return searchService.recommend(request);
    }

    /**
     * Live transparency endpoint: which AI providers are actually configured
     * and, from the most recent /recommend call, which ones actually served
     * the response (vs. silently falling back to the local/template engine).
     * Never exposes the API key itself, only whether one is present.
     */
    @GetMapping("/ai-status")
    public Map<String, Object> getAiStatus() {
        SemanticSearchService.AiRunStatus last = searchService.lastRunStatus();

        Map<String, Object> embeddings = new LinkedHashMap<>();
        embeddings.put("configuredProvider", embeddingService.configuredProvider());
        embeddings.put("azureCredentialsPresent", embeddingService.azureConfigured());
        embeddings.put("activeProvider", embeddingService.activeProviderId());
        embeddings.put("lastRequestUsedProvider", last.embeddingProvider());
        embeddings.put("lastRequestFellBack", last.embeddingFellBack());
        embeddings.put("lastFallbackReason", last.embeddingFallbackReason());

        Map<String, Object> explanation = new LinkedHashMap<>();
        explanation.put("lastRequestUsedProvider", last.explanationProvider());
        explanation.put("lastRequestFellBack", last.explanationFellBack());
        explanation.put("lastFallbackReason", last.explanationFallbackReason());

        Map<String, Object> status = new LinkedHashMap<>();
        status.put("embeddings", embeddings);
        status.put("explanation", explanation);
        return status;
    }

    /**
     * Static demo KPIs mirroring the targets captured in the SmartSAT AI
     * idea submission. In production these would be computed from real
     * usage telemetry (discovery time before/after, SME escalations, etc).
     */
    @GetMapping("/kpis")
    public List<Map<String, String>> getKpis() {
        return List.of(
                kpi("Reduce SAT User Discovery Time", "70-80%", "Manual Excel/SME lookup vs. AI-assisted search"),
                kpi("Increase Team Productivity", "30-40%", "Across Testers, Developers, POs and BAs"),
                kpi("Reduce SME / Domain Dependency", "50%", "Self-service discovery vs. escalation to SMEs"),
                kpi("Accelerate Testing & Release Cycles", "25-30%", "Faster test/analysis setup end-to-end")
        );
    }

    @GetMapping("/use-case")
    public Map<String, Object> getUseCase() {
        Map<String, Object> res = new LinkedHashMap<>();
        res.put("name", "SmartSAT AI");
        res.put("tagline", "Intelligent Module-Based Test User Discovery for the Peregrine UI app");
        res.put("summary",
                "SmartSAT AI is an AI-powered SAT User Discovery Assistant that helps testers, " +
                "developers, product owners and business analysts instantly find the most suitable " +
                "SAT users for a given Peregrine module, instead of manually searching Excel files, " +
                "client data and SME knowledge.");
        res.put("valueChain", List.of(
                "User selects a Peregrine module (RSM / CMAX / RR / Paycheck Deduction / Contributions)",
                "AI analyzes module rules, SAT user data & client profiles",
                "Relevant SAT users are recommended via RAG + semantic search",
                "User selects the best-fit profile",
                "Faster test/analysis setup, reduced manual search & SME dependency",
                "Faster validation, testing & decision-making",
                "Reduced release delays, accelerated delivery & enhanced quality"
        ));
        res.put("personas", List.of(
                "Testers / QA Engineers", "Developers", "Product Owners",
                "Business Analysts", "Project Managers", "Release Management Teams"
        ));
        return res;
    }

    private Map<String, String> kpi(String label, String target, String detail) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("label", label);
        m.put("target", target);
        m.put("detail", detail);
        return m;
    }
}
