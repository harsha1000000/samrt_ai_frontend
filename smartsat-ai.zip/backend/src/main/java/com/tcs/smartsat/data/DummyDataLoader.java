package com.tcs.smartsat.data;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tcs.smartsat.model.SatUser;
import jakarta.annotation.PostConstruct;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Loads the dummy SAT user dataset (src/main/resources/data/sat_users.json)
 * into memory at startup. This stands in for the real "SAT user data +
 * client profiles" source described in the use case (today stored in Excel).
 *
 * Swap this out for a real repository (DB, Excel ingestion pipeline, or an
 * upstream Peregrine service call) without touching the search/RAG layer -
 * everything downstream only depends on List<SatUser>.
 */
@Component
public class DummyDataLoader {

    private List<SatUser> users = Collections.emptyList();

    @PostConstruct
    public void load() {
        try (InputStream is = new ClassPathResource("data/sat_users.json").getInputStream()) {
            ObjectMapper mapper = new ObjectMapper();
            SatUser[] arr = mapper.readValue(is, SatUser[].class);
            this.users = List.of(arr);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to load dummy SAT user dataset", e);
        }
    }

    public List<SatUser> getAllUsers() {
        return users;
    }

    public List<SatUser> getByModule(String module) {
        return users.stream()
                .filter(u -> u.getModule().equalsIgnoreCase(module))
                .collect(Collectors.toList());
    }

    public List<String> getAllModules() {
        return users.stream()
                .map(SatUser::getModule)
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }
}
