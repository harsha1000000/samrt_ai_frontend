package com.tcs.smartsat.model;

import jakarta.validation.constraints.NotBlank;

public class RecommendationRequest {

    @NotBlank(message = "module is required")
    private String module;

    /** Free-text testing scenario, e.g. "participant near contribution limit with a loan" */
    private String scenario;

    private Integer topK = 3;

    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }

    public String getScenario() { return scenario; }
    public void setScenario(String scenario) { this.scenario = scenario; }

    public Integer getTopK() { return topK; }
    public void setTopK(Integer topK) { this.topK = topK; }
}
