package com.tcs.smartsat.model;

public class RecommendationResult {
    private SatUser user;
    private double matchScore;      // 0-100
    private String matchReason;     // RAG-generated explanation

    public RecommendationResult(SatUser user, double matchScore, String matchReason) {
        this.user = user;
        this.matchScore = matchScore;
        this.matchReason = matchReason;
    }

    public SatUser getUser() { return user; }
    public double getMatchScore() { return matchScore; }
    public String getMatchReason() { return matchReason; }
}
