package com.tcs.smartsat.model;

import java.util.List;

public class SatUser {
    private String id;
    private String module;
    private String clientName;
    private String planType;
    private List<String> roles;
    private String description;
    private String dataQuality;
    private String lastValidated;

    public SatUser() {
    }

    // --- getters / setters ---
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }

    public String getClientName() { return clientName; }
    public void setClientName(String clientName) { this.clientName = clientName; }

    public String getPlanType() { return planType; }
    public void setPlanType(String planType) { this.planType = planType; }

    public List<String> getRoles() { return roles; }
    public void setRoles(List<String> roles) { this.roles = roles; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDataQuality() { return dataQuality; }
    public void setDataQuality(String dataQuality) { this.dataQuality = dataQuality; }

    public String getLastValidated() { return lastValidated; }
    public void setLastValidated(String lastValidated) { this.lastValidated = lastValidated; }
}
