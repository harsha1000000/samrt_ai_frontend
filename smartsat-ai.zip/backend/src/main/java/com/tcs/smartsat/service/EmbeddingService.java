package com.tcs.smartsat.service;

import com.tcs.smartsat.model.SatUser;
import com.tcs.smartsat.service.embedding.AzureOpenAiEmbeddingProvider;
import com.tcs.smartsat.service.embedding.EmbeddingContext;
import com.tcs.smartsat.service.embedding.EmbeddingProvider;
import com.tcs.smartsat.service.embedding.EmbeddingProviderException;
import com.tcs.smartsat.service.embedding.LocalTfIdfEmbeddingProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Picks which {@link EmbeddingProvider} backs semantic search and
 * guarantees a safe fallback: if `smartsat.embeddings.provider=azure-openai`
 * but the call fails for any reason (no key, network blip, quota, wrong
 * deployment name), the request transparently falls back to the local
 * TF-IDF engine instead of failing the demo. The failure is logged and
 * exposed via {@link #resolve} so the caller (and /api/ai-status) can show
 * it in the UI rather than hiding it.
 */
@Service
public class EmbeddingService {

    private static final Logger log = LoggerFactory.getLogger(EmbeddingService.class);

    @Value("${smartsat.embeddings.provider:local}")
    private String configuredProvider;

    private final LocalTfIdfEmbeddingProvider localProvider;
    private final AzureOpenAiEmbeddingProvider azureProvider;

    public EmbeddingService(LocalTfIdfEmbeddingProvider localProvider, AzureOpenAiEmbeddingProvider azureProvider) {
        this.localProvider = localProvider;
        this.azureProvider = azureProvider;
    }

    /** Resolves a provider for one recommend() call and embeds the query with it, up front. */
    public EmbeddingContext resolve(String queryText) {
        EmbeddingProvider primary = wantsAzure() && azureProvider.isAvailable() ? azureProvider : localProvider;

        if (primary == localProvider) {
            return context(localProvider, queryText, false, null);
        }

        try {
            double[] queryVector = primary.embedQuery(queryText);
            return new EmbeddingContext(primary, queryVector, false, null);
        } catch (EmbeddingProviderException e) {
            log.warn("Azure OpenAI embeddings call failed, falling back to local TF-IDF: {}", e.getMessage());
            return context(localProvider, queryText, true, e.getMessage());
        }
    }

    /**
     * Rebuilds the context against the local provider, for when a remote
     * provider fails PARTWAY through a request (e.g. document #3 of 8 hits
     * a quota error after the query embedded fine). Called by
     * SemanticSearchService if it catches an EmbeddingProviderException
     * while scoring candidates, so the whole request still completes
     * consistently in one vector space instead of crashing.
     */
    public EmbeddingContext forceLocal(String queryText, String reason) {
        return context(localProvider, queryText, true, reason);
    }

    /** Which provider *would* be used right now, without making a call — used by /api/ai-status. */
    public String activeProviderId() {
        return (wantsAzure() && azureProvider.isAvailable()) ? azureProvider.providerId() : localProvider.providerId();
    }

    public String configuredProvider() {
        return configuredProvider;
    }

    public boolean azureConfigured() {
        return azureProvider.isAvailable();
    }

    public List<String> sharedTerms(String queryText, SatUser user) {
        return TextUtils.sharedTerms(queryText, user);
    }

    private boolean wantsAzure() {
        return "azure-openai".equalsIgnoreCase(configuredProvider);
    }

    private EmbeddingContext context(EmbeddingProvider provider, String queryText, boolean fellBack, String reason) {
        return new EmbeddingContext(provider, provider.embedQuery(queryText), fellBack, reason);
    }
}
