package com.tcs.smartsat.service;

import com.tcs.smartsat.data.DummyDataLoader;
import com.tcs.smartsat.model.RecommendationRequest;
import com.tcs.smartsat.model.RecommendationResult;
import com.tcs.smartsat.model.SatUser;
import com.tcs.smartsat.service.embedding.EmbeddingContext;
import com.tcs.smartsat.service.embedding.EmbeddingProviderException;
import com.tcs.smartsat.service.explain.ExplanationGenerator;
import com.tcs.smartsat.service.explain.ExplanationProviderException;
import com.tcs.smartsat.service.explain.GptExplanationGenerator;
import com.tcs.smartsat.service.explain.TemplateExplanationGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * RAG orchestrator for SmartSAT AI.
 *
 * RETRIEVE : filter candidate SAT users to the selected Peregrine module,
 *            then rank the remaining candidates by semantic similarity
 *            between the query (module + free-text scenario) and each
 *            user's profile, via EmbeddingService.
 *
 * AUGMENT  : the top-K retrieved profiles become the grounding context
 *            handed to the explanation generator.
 *
 * GENERATE : each result's explanation comes from either real GPT (Azure
 *            OpenAI chat completions) or a deterministic template,
 *            depending on `smartsat.explanation.provider` — with the same
 *            "never break the demo" fallback used for embeddings.
 */
@Service
public class SemanticSearchService {

    private static final Logger log = LoggerFactory.getLogger(SemanticSearchService.class);

    @Value("${smartsat.explanation.provider:template}")
    private String configuredExplanationProvider;

    private final DummyDataLoader dataLoader;
    private final EmbeddingService embeddingService;
    private final TemplateExplanationGenerator templateExplanationGenerator;
    private final GptExplanationGenerator gptExplanationGenerator;

    /** Status of the most recently served request — backs /api/ai-status. */
    private volatile AiRunStatus lastRunStatus = AiRunStatus.notRunYet();

    public SemanticSearchService(DummyDataLoader dataLoader,
                                  EmbeddingService embeddingService,
                                  TemplateExplanationGenerator templateExplanationGenerator,
                                  GptExplanationGenerator gptExplanationGenerator) {
        this.dataLoader = dataLoader;
        this.embeddingService = embeddingService;
        this.templateExplanationGenerator = templateExplanationGenerator;
        this.gptExplanationGenerator = gptExplanationGenerator;
    }

    public List<RecommendationResult> recommend(RecommendationRequest request) {
        String module = request.getModule();
        String scenario = request.getScenario() == null ? "" : request.getScenario();
        int topK = request.getTopK() == null || request.getTopK() <= 0 ? 3 : request.getTopK();

        // 1. RETRIEVE: business-rule filter by module
        List<SatUser> candidates = dataLoader.getByModule(module);

        // Query text mirrors what a real embedding call would be fed
        String queryText = module + " " + scenario;
        EmbeddingContext embeddingContext = embeddingService.resolve(queryText);

        ExplanationGenerator explanationGenerator = wantsGpt() && gptExplanationGenerator.isAvailable()
                ? gptExplanationGenerator
                : templateExplanationGenerator;

        boolean[] explanationFellBack = {false};
        String[] explanationFallbackReason = {null};

        // 2. RANK + 3. GENERATE
        List<RecommendationResult> results;
        try {
            results = scoreAndExplain(candidates, embeddingContext, scenario, topK,
                    explanationGenerator, explanationFellBack, explanationFallbackReason);
        } catch (EmbeddingProviderException e) {
            // Azure succeeded for the query but failed partway through scoring candidates
            // (e.g. quota hit on document #3). Rebuild in the local vector space so the
            // whole request still completes consistently instead of crashing the demo.
            log.warn("Azure OpenAI embeddings failed mid-request, retrying locally: {}", e.getMessage());
            embeddingContext = embeddingService.forceLocal(queryText, e.getMessage());
            results = scoreAndExplain(candidates, embeddingContext, scenario, topK,
                    explanationGenerator, explanationFellBack, explanationFallbackReason);
        }

        lastRunStatus = new AiRunStatus(
                embeddingContext.providerId(), embeddingContext.fellBack(), embeddingContext.fallbackReason(),
                explanationGenerator.providerId(), explanationFellBack[0], explanationFallbackReason[0]
        );

        return results;
    }

    public AiRunStatus lastRunStatus() {
        return lastRunStatus;
    }

    private List<RecommendationResult> scoreAndExplain(List<SatUser> candidates,
                                                         EmbeddingContext embeddingContext,
                                                         String scenario,
                                                         int topK,
                                                         ExplanationGenerator explanationGenerator,
                                                         boolean[] explanationFellBack,
                                                         String[] explanationFallbackReason) {
        return candidates.stream()
                .map(user -> {
                    double similarity = embeddingContext.similarity(user);
                    double score = normalizeScore(similarity, scenario.isBlank());
                    List<String> shared = scenario.isBlank()
                            ? List.of()
                            : embeddingService.sharedTerms(scenario, user);

                    String reason = generateExplanation(
                            explanationGenerator, user, scenario, score, shared,
                            explanationFellBack, explanationFallbackReason);

                    return new RecommendationResult(user, score, reason);
                })
                .sorted(Comparator.comparingDouble(RecommendationResult::getMatchScore).reversed())
                .limit(topK)
                .collect(Collectors.toList());
    }

    private String generateExplanation(ExplanationGenerator generator, SatUser user, String scenario,
                                        double score, List<String> shared,
                                        boolean[] fellBackOut, String[] reasonOut) {
        if (generator == templateExplanationGenerator) {
            return templateExplanationGenerator.explain(user, scenario, score, shared);
        }
        try {
            return generator.explain(user, scenario, score, shared);
        } catch (ExplanationProviderException e) {
            log.warn("Azure GPT explanation call failed for user {}, falling back to template: {}",
                    user.getId(), e.getMessage());
            fellBackOut[0] = true;
            reasonOut[0] = e.getMessage();
            return templateExplanationGenerator.explain(user, scenario, score, shared);
        }
    }

    private boolean wantsGpt() {
        return "azure-gpt".equalsIgnoreCase(configuredExplanationProvider);
    }

    /**
     * Cosine similarity on a sparse TF-IDF space (or a dense embedding
     * space) tends to sit in a fairly narrow band for short queries.
     * Rescale to a 0-100 "match score" that is easier to read in the UI,
     * and give every module-matched candidate a reasonable floor so
     * results still look useful for a blank scenario.
     */
    private double normalizeScore(double cosineSim, boolean scenarioBlank) {
        if (scenarioBlank) {
            return 62 + Math.min(cosineSim * 400, 30);
        }
        double scaled = 55 + Math.min(cosineSim * 550, 44);
        return Math.round(scaled * 10.0) / 10.0;
    }

    /** Snapshot of what actually served the last /api/recommend call — exposed via /api/ai-status. */
    public record AiRunStatus(
            String embeddingProvider, boolean embeddingFellBack, String embeddingFallbackReason,
            String explanationProvider, boolean explanationFellBack, String explanationFallbackReason
    ) {
        static AiRunStatus notRunYet() {
            return new AiRunStatus("local-tfidf", false, null, "template", false, null);
        }
    }
}
