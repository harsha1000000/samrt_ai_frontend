package com.tcs.smartsat.service;

import com.tcs.smartsat.model.SatUser;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Text helpers shared by every embedding provider (local TF-IDF and remote
 * Azure OpenAI) and by the explanation generators, so tokenization and the
 * "what text represents a SAT user" decision live in exactly one place.
 */
public final class TextUtils {

    private static final Pattern TOKEN_PATTERN = Pattern.compile("[a-zA-Z0-9]+");
    private static final Set<String> STOPWORDS = Set.of(
            "a", "an", "the", "and", "or", "with", "for", "of", "in", "on", "to",
            "is", "are", "test", "user", "users", "using", "used", "over"
    );

    private TextUtils() {
    }

    /** Combines the fields a real embedding model would be fed for this SAT user. */
    public static String documentText(SatUser user) {
        return String.join(" ",
                user.getModule(),
                user.getPlanType() == null ? "" : user.getPlanType(),
                user.getClientName() == null ? "" : user.getClientName(),
                user.getRoles() == null ? "" : String.join(" ", user.getRoles()),
                user.getDescription() == null ? "" : user.getDescription()
        );
    }

    public static List<String> tokenize(String text) {
        if (text == null) return List.of();
        List<String> tokens = new ArrayList<>();
        var matcher = TOKEN_PATTERN.matcher(text.toLowerCase(Locale.ROOT));
        while (matcher.find()) {
            String t = matcher.group();
            if (!STOPWORDS.contains(t) && t.length() > 1) {
                tokens.add(t);
            }
        }
        return tokens;
    }

    /** Terms shared between query and document — used to build the RAG explanation. */
    public static List<String> sharedTerms(String queryText, SatUser user) {
        Set<String> queryTerms = new LinkedHashSet<>(tokenize(queryText));
        Set<String> docTerms = new HashSet<>(tokenize(documentText(user)));
        queryTerms.retainAll(docTerms);
        return queryTerms.stream().filter(t -> !STOPWORDS.contains(t)).collect(Collectors.toList());
    }

    public static double cosineSimilarity(double[] a, double[] b) {
        double dot = 0, normA = 0, normB = 0;
        for (int i = 0; i < a.length; i++) {
            dot += a[i] * b[i];
            normA += a[i] * a[i];
            normB += b[i] * b[i];
        }
        if (normA == 0 || normB == 0) return 0.0;
        return dot / (Math.sqrt(normA) * Math.sqrt(normB));
    }
}
