package com.tcs.smartsat.service.azure;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;

/**
 * Thin HTTP client for Azure OpenAI's embeddings and chat-completions
 * REST APIs. Deliberately dependency-light: java.net.http (built into the
 * JDK) + the Jackson ObjectMapper already on the classpath, no SDK.
 *
 * This class only knows how to make the two calls and parse their
 * responses. Deciding WHEN to call it (vs. falling back to local logic)
 * lives in {@code EmbeddingService} and the explanation generators — this
 * client just throws on any failure so callers can catch and fall back.
 */
@Component
public class AzureOpenAiClient {

    private static final Logger log = LoggerFactory.getLogger(AzureOpenAiClient.class);
    private static final String EMBEDDINGS_API_VERSION = "2023-05-15";
    private static final String CHAT_API_VERSION = "2024-02-15-preview";

    @Value("${smartsat.embeddings.azure.endpoint:}")
    private String endpoint;

    @Value("${smartsat.embeddings.azure.api-key:}")
    private String apiKey;

    @Value("${smartsat.embeddings.azure.deployment-name:text-embedding-3-small}")
    private String embeddingDeployment;

    @Value("${smartsat.explanation.azure.deployment-name:gpt-4o-mini}")
    private String chatDeployment;

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    private final ObjectMapper mapper = new ObjectMapper();

    public boolean isConfigured() {
        return endpoint != null && !endpoint.isBlank()
                && apiKey != null && !apiKey.isBlank();
    }

    /** Embeds a batch of texts in one call and returns the vectors in the same order. */
    public List<double[]> embed(List<String> texts) throws AzureOpenAiException {
        requireConfigured();
        String url = trimTrailingSlash(endpoint)
                + "/openai/deployments/" + embeddingDeployment
                + "/embeddings?api-version=" + EMBEDDINGS_API_VERSION;

        ObjectNode body = mapper.createObjectNode();
        ArrayNode input = body.putArray("input");
        texts.forEach(input::add);

        JsonNode response = post(url, body);
        JsonNode data = response.path("data");
        if (!data.isArray() || data.size() != texts.size()) {
            throw new AzureOpenAiException("Unexpected embeddings response shape from Azure OpenAI");
        }

        List<double[]> vectors = new java.util.ArrayList<>();
        for (JsonNode item : data) {
            JsonNode embeddingNode = item.path("embedding");
            double[] vec = new double[embeddingNode.size()];
            for (int i = 0; i < vec.length; i++) {
                vec[i] = embeddingNode.get(i).asDouble();
            }
            vectors.add(vec);
        }
        return vectors;
    }

    /** Sends a single chat-completion request and returns the assistant's text. */
    public String chatComplete(String systemPrompt, String userPrompt) throws AzureOpenAiException {
        requireConfigured();
        String url = trimTrailingSlash(endpoint)
                + "/openai/deployments/" + chatDeployment
                + "/chat/completions?api-version=" + CHAT_API_VERSION;

        ObjectNode body = mapper.createObjectNode();
        ArrayNode messages = body.putArray("messages");
        messages.addObject().put("role", "system").put("content", systemPrompt);
        messages.addObject().put("role", "user").put("content", userPrompt);
        body.put("temperature", 0.3);
        body.put("max_tokens", 220);

        JsonNode response = post(url, body);
        JsonNode choices = response.path("choices");
        if (!choices.isArray() || choices.isEmpty()) {
            throw new AzureOpenAiException("Unexpected chat-completions response shape from Azure OpenAI");
        }
        return choices.get(0).path("message").path("content").asText("").trim();
    }

    private JsonNode post(String url, ObjectNode body) throws AzureOpenAiException {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .timeout(Duration.ofSeconds(15))
                    .header("Content-Type", "application/json")
                    .header("api-key", apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() / 100 != 2) {
                throw new AzureOpenAiException(
                        "Azure OpenAI call failed: HTTP " + response.statusCode() + " - " + truncate(response.body()));
            }
            return mapper.readTree(response.body());
        } catch (AzureOpenAiException e) {
            throw e;
        } catch (Exception e) {
            log.warn("Azure OpenAI call errored: {}", e.getMessage());
            throw new AzureOpenAiException("Azure OpenAI call errored: " + e.getMessage(), e);
        }
    }

    private void requireConfigured() throws AzureOpenAiException {
        if (!isConfigured()) {
            throw new AzureOpenAiException(
                    "Azure OpenAI is not configured (set smartsat.embeddings.azure.endpoint and api-key)");
        }
    }

    private String truncate(String s) {
        return s == null ? "" : s.length() > 300 ? s.substring(0, 300) + "..." : s;
    }

    private String trimTrailingSlash(String s) {
        return s.endsWith("/") ? s.substring(0, s.length() - 1) : s;
    }
}
