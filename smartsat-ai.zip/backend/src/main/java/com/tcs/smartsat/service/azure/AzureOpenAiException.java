package com.tcs.smartsat.service.azure;

/** Thrown whenever an Azure OpenAI call can't be made or fails — always safe to catch and fall back on. */
public class AzureOpenAiException extends Exception {
    public AzureOpenAiException(String message) {
        super(message);
    }

    public AzureOpenAiException(String message, Throwable cause) {
        super(message, cause);
    }
}
