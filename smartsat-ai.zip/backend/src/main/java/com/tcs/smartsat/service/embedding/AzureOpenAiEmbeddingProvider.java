package com.tcs.smartsat.service.embedding;

import com.tcs.smartsat.model.SatUser;
import com.tcs.smartsat.service.TextUtils;
import com.tcs.smartsat.service.azure.AzureOpenAiClient;
import com.tcs.smartsat.service.azure.AzureOpenAiException;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Real semantic embeddings via Azure OpenAI (text-embedding-3-small by
 * default). Document vectors are computed once per SAT user and cached —
 * only queries hit the API on every request.
 *
 * Any failure (missing credentials, network error, non-2xx response) is
 * surfaced as an unchecked {@link EmbeddingProviderException} so the
 * orchestrating {@code EmbeddingService} can catch it and fall back to the
 * local TF-IDF provider without the demo breaking.
 */
@Component
public class AzureOpenAiEmbeddingProvider implements EmbeddingProvider {

    private final AzureOpenAiClient client;
    private final Map<String, double[]> documentCache = new ConcurrentHashMap<>();

    public AzureOpenAiEmbeddingProvider(AzureOpenAiClient client) {
        this.client = client;
    }

    @Override
    public double[] embedDocument(SatUser user) {
        double[] cached = documentCache.get(user.getId());
        if (cached != null) {
            return cached;
        }
        double[] vec = embedSingle(TextUtils.documentText(user));
        documentCache.put(user.getId(), vec);
        return vec;
    }

    @Override
    public double[] embedQuery(String text) {
        return embedSingle(text);
    }

    @Override
    public String providerId() {
        return "azure-openai";
    }

    @Override
    public boolean isAvailable() {
        return client.isConfigured();
    }

    private double[] embedSingle(String text) {
        try {
            List<double[]> result = client.embed(List.of(text.isBlank() ? " " : text));
            return result.get(0);
        } catch (AzureOpenAiException e) {
            throw new EmbeddingProviderException(e.getMessage(), e);
        }
    }
}
