package com.tcs.smartsat.service.embedding;

import com.tcs.smartsat.model.SatUser;
import com.tcs.smartsat.service.TextUtils;

/**
 * The result of resolving which embedding provider to use for ONE
 * recommend() call. Query and document vectors must come from the same
 * provider or cosine similarity is meaningless (different dimensionality,
 * different vector space) — so this is computed once per request and
 * reused for every candidate, rather than letting the provider choice
 * drift mid-request if Azure happens to fail partway through.
 */
public class EmbeddingContext {

    private final EmbeddingProvider provider;
    private final double[] queryVector;
    private final boolean fellBack;
    private final String fallbackReason;

    public EmbeddingContext(EmbeddingProvider provider, double[] queryVector, boolean fellBack, String fallbackReason) {
        this.provider = provider;
        this.queryVector = queryVector;
        this.fellBack = fellBack;
        this.fallbackReason = fallbackReason;
    }

    public double[] queryVector() {
        return queryVector;
    }

    public double[] embedDocument(SatUser user) {
        return provider.embedDocument(user);
    }

    public double similarity(SatUser user) {
        return TextUtils.cosineSimilarity(queryVector, embedDocument(user));
    }

    public String providerId() {
        return provider.providerId();
    }

    public boolean fellBack() {
        return fellBack;
    }

    public String fallbackReason() {
        return fallbackReason;
    }
}
