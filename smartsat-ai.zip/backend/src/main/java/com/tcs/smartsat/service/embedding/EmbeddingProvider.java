package com.tcs.smartsat.service.embedding;

import com.tcs.smartsat.model.SatUser;

/**
 * A source of vector embeddings for SAT user profiles and free-text
 * queries. Implementations may be local (no network) or remote (a real
 * embedding model such as Azure OpenAI's text-embedding-3-small).
 *
 * Every implementation must be able to embed both sides (document + query)
 * into the SAME vector space, since callers compare them with cosine
 * similarity.
 */
public interface EmbeddingProvider {

    double[] embedDocument(SatUser user);

    double[] embedQuery(String text);

    /** Short, human-readable id used in logs and the /api/ai-status response, e.g. "local-tfidf" or "azure-openai". */
    String providerId();

    /** Whether this provider is actually usable right now (e.g. remote providers need credentials configured). */
    boolean isAvailable();
}
