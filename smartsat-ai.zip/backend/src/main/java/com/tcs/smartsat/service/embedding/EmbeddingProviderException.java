package com.tcs.smartsat.service.embedding;

/** Unchecked wrapper so EmbeddingProvider methods don't need `throws` — callers catch this to trigger fallback. */
public class EmbeddingProviderException extends RuntimeException {
    public EmbeddingProviderException(String message, Throwable cause) {
        super(message, cause);
    }
}
