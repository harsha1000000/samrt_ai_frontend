package com.tcs.smartsat.service.embedding;

import com.tcs.smartsat.data.DummyDataLoader;
import com.tcs.smartsat.model.SatUser;
import com.tcs.smartsat.service.TextUtils;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Zero-dependency, zero-network "semantic search" engine using a classic
 * TF-IDF vector space model + cosine similarity.
 *
 * This is always available (it never calls out to the network), so it is
 * both the default provider and the automatic fallback for
 * {@link AzureOpenAiEmbeddingProvider} if a real API call fails.
 */
@Component
public class LocalTfIdfEmbeddingProvider implements EmbeddingProvider {

    private final DummyDataLoader dataLoader;

    /** vocabulary -> index */
    private final Map<String, Integer> vocabulary = new HashMap<>();
    /** inverse document frequency per vocabulary term */
    private double[] idf;
    /** pre-computed TF-IDF vector per SAT user id */
    private final Map<String, double[]> documentVectors = new HashMap<>();

    public LocalTfIdfEmbeddingProvider(DummyDataLoader dataLoader) {
        this.dataLoader = dataLoader;
    }

    @PostConstruct
    public void buildIndex() {
        List<SatUser> users = dataLoader.getAllUsers();
        List<List<String>> tokenizedDocs = new ArrayList<>();

        for (SatUser user : users) {
            tokenizedDocs.add(TextUtils.tokenize(TextUtils.documentText(user)));
        }

        // 1. build vocabulary
        int idx = 0;
        for (List<String> doc : tokenizedDocs) {
            for (String term : doc) {
                if (!vocabulary.containsKey(term)) {
                    vocabulary.put(term, idx++);
                }
            }
        }

        // 2. document frequency -> idf
        int[] docFreq = new int[vocabulary.size()];
        for (List<String> doc : tokenizedDocs) {
            Set<String> seen = new HashSet<>(doc);
            for (String term : seen) {
                docFreq[vocabulary.get(term)]++;
            }
        }
        int totalDocs = tokenizedDocs.size();
        idf = new double[vocabulary.size()];
        for (int i = 0; i < idf.length; i++) {
            idf[i] = Math.log((double) (totalDocs + 1) / (docFreq[i] + 1)) + 1.0;
        }

        // 3. TF-IDF vector per document
        for (int i = 0; i < users.size(); i++) {
            documentVectors.put(users.get(i).getId(), vectorize(tokenizedDocs.get(i)));
        }
    }

    @Override
    public double[] embedDocument(SatUser user) {
        return documentVectors.getOrDefault(user.getId(),
                vectorize(TextUtils.tokenize(TextUtils.documentText(user))));
    }

    @Override
    public double[] embedQuery(String text) {
        return vectorize(TextUtils.tokenize(text));
    }

    @Override
    public String providerId() {
        return "local-tfidf";
    }

    @Override
    public boolean isAvailable() {
        return true;
    }

    private double[] vectorize(List<String> tokens) {
        double[] vec = new double[vocabulary.size()];
        if (tokens.isEmpty() || vocabulary.isEmpty()) return vec;

        Map<String, Long> tf = tokens.stream()
                .filter(vocabulary::containsKey)
                .collect(Collectors.groupingBy(t -> t, Collectors.counting()));

        for (var entry : tf.entrySet()) {
            int i = vocabulary.get(entry.getKey());
            double termFreq = (double) entry.getValue() / tokens.size();
            vec[i] = termFreq * idf[i];
        }
        return vec;
    }
}
