package com.tcs.smartsat.service.explain;

import com.tcs.smartsat.model.SatUser;

import java.util.List;

/**
 * The GENERATE step of RAG: turns a retrieved SAT user profile + the
 * original query into a natural-language "why this user" explanation.
 */
public interface ExplanationGenerator {

    String explain(SatUser user, String scenario, double matchScore, List<String> sharedTerms);

    String providerId();

    boolean isAvailable();
}
