package com.tcs.smartsat.service.explain;

/** Unchecked wrapper so ExplanationGenerator.explain() doesn't need `throws` — callers catch this to fall back. */
public class ExplanationProviderException extends RuntimeException {
    public ExplanationProviderException(String message, Throwable cause) {
        super(message, cause);
    }
}
