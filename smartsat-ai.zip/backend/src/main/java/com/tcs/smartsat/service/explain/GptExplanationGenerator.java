package com.tcs.smartsat.service.explain;

import com.tcs.smartsat.model.SatUser;
import com.tcs.smartsat.service.azure.AzureOpenAiClient;
import com.tcs.smartsat.service.azure.AzureOpenAiException;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Real GPT-generated explanations via Azure OpenAI chat completions. The
 * retrieved SAT user profile is passed in as grounding context (the
 * "augment" step of RAG) so the model explains THIS record rather than
 * hallucinating one.
 *
 * Throws {@link ExplanationProviderException} (unchecked) on any failure
 * so {@code SemanticSearchService} can catch it and fall back to the
 * template generator per-result, without crashing the whole request.
 */
@Component
public class GptExplanationGenerator implements ExplanationGenerator {

    private static final String SYSTEM_PROMPT = """
            You are an assistant inside SmartSAT AI, a tool that helps testers pick the right \
            test user (SAT user) for a Peregrine module testing scenario. You are given ONE \
            retrieved SAT user profile and the tester's scenario. Write a concise (2-3 sentence) \
            explanation of why this profile is a good match, grounded ONLY in the profile fields \
            given to you. Do not invent details not present in the profile. Mention data quality \
            if it is medium, so the tester knows to double check it.""";

    private final AzureOpenAiClient client;

    public GptExplanationGenerator(AzureOpenAiClient client) {
        this.client = client;
    }

    @Override
    public String explain(SatUser user, String scenario, double matchScore, List<String> sharedTerms) {
        String userPrompt = """
                Tester's scenario: %s

                Retrieved SAT user profile:
                - Module: %s
                - Client: %s
                - Plan type: %s
                - Roles: %s
                - Description: %s
                - Data quality: %s
                - Match score: %.1f / 100
                """.formatted(
                scenario == null || scenario.isBlank() ? "(none provided — general recommendation)" : scenario,
                user.getModule(),
                user.getClientName(),
                user.getPlanType(),
                user.getRoles() == null ? "" : String.join(", ", user.getRoles()),
                user.getDescription(),
                user.getDataQuality(),
                matchScore
        );

        try {
            String result = client.chatComplete(SYSTEM_PROMPT, userPrompt);
            if (result == null || result.isBlank()) {
                throw new ExplanationProviderException("Azure OpenAI returned an empty explanation", null);
            }
            return result;
        } catch (AzureOpenAiException e) {
            throw new ExplanationProviderException(e.getMessage(), e);
        }
    }

    @Override
    public String providerId() {
        return "azure-gpt";
    }

    @Override
    public boolean isAvailable() {
        return client.isConfigured();
    }
}
