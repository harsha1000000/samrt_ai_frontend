package com.tcs.smartsat.service.explain;

import com.tcs.smartsat.model.SatUser;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Deterministic, template-based stand-in for an LLM call. Always
 * available (no network), so it's both the default and the automatic
 * fallback for {@link GptExplanationGenerator}.
 */
@Component
public class TemplateExplanationGenerator implements ExplanationGenerator {

    @Override
    public String explain(SatUser user, String scenario, double matchScore, List<String> sharedTerms) {
        StringBuilder sb = new StringBuilder();
        sb.append("Recommended for ").append(user.getModule()).append(" testing on ")
          .append(user.getClientName()).append(" (").append(user.getPlanType()).append("). ");

        if (sharedTerms != null && !sharedTerms.isEmpty()) {
            sb.append("Matches your scenario on: ")
              .append(String.join(", ", sharedTerms.stream().limit(5).toList()))
              .append(". ");
        }

        sb.append(user.getDescription());

        if ("High".equalsIgnoreCase(user.getDataQuality())) {
            sb.append(" Profile data is fully validated, so it's safe to use without extra clean-up.");
        } else {
            sb.append(" Data quality is medium — spot-check key fields before relying on it for a demo.");
        }
        return sb.toString();
    }

    @Override
    public String providerId() {
        return "template";
    }

    @Override
    public boolean isAvailable() {
        return true;
    }
}
